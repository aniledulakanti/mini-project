from django.apps import AppConfig


class SoilappConfig(AppConfig):
    name = 'SoilApp'
